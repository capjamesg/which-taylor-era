// @input Component.ScriptComponent spinnerController

script.spinnerController.promptText = "Default Prompt";
script.spinnerController.defaultText = "Default Result";
script.spinnerController.content = [
    {
        text: "option 1",
        color: new vec4(1,0,0,1)
    },
    {
        text: "option 2",
        color: new vec4(0,1,0,1)
    },
    {
        text: "option 3",
        color: new vec4(0,0,1,1)
    }
];

// Update the visuals of the spinner to match the new content
script.spinnerController.initVisuals();
