// ImageLookCustomizer.js
// Version: 0.1.0
// Event: Lens Initialized
// Description: Exposes some common image component settings. Useful when
// you want to control some image component on a different object.

//@input Component.Image imageDisplay
/** @type {Image} */
var imageDisplay = script.imageDisplay;

//@ui {"widget":"separator"}

//@input bool modifyLook
/** @type {boolean} */
var modifyLook = script.modifyLook;

//@ui {"widget":"group_start", "label":"Settings", "showIf": "modifyLook"}

//@input float imageSize = 1 {"widget":"slider", "min":0.0, "max":2.0, "step":0.01 }
/** @type {number} */
var imageSize = script.imageSize;

//@input vec4 imageOffset
/** @type {vec4} */
var imageOffset = script.imageOffset;

//@ui {"widget":"group_end"}

function modifyImageVisual(imageDisplay) {

    var screenTransform = imageDisplay.getSceneObject().getComponent("ScreenTransform");
    if (screenTransform) {
        var offset = Rect.create(imageOffset.x, imageOffset.y, imageOffset.z, imageOffset.w);
        screenTransform.imageOffsets = offset;
    }

    var size = vec3.one().uniformScale(imageSize);
    imageDisplay.getSceneObject().getTransform().setLocalScale(size);
}

function validateInputs() {
    if (!(modifyLook ? imageDisplay : true)) {
        Studio.log("[ImageLookCustomizer][Error] Please ensure `Image Display` is set, or uncheck `Modify Look`. This is the Image that will be modified.");
        return false;
    }
    return true;
}

function init() {
    if (!validateInputs()) {
        return false;
    }

    if (modifyLook) {
        modifyImageVisual(imageDisplay);
    }
}

init();