// SpinnerController.js
// Version: 0.1.0
// Event: Lens Initialized
// Description: Given a list of content, and some image/text visuals, 
// this script will randomly spin through the list of content 
// until arriving at a final one, on some trigger.

/*
@typedef SpinnerItem
@property {string} text
@property {Asset.Texture} image
@property {vec4} color {"widget": "color"}
*/

//@input bool displayPrompt
/** @type {boolean} */
var displayPrompt = script.displayPrompt;

//@input string promptText {"widget" : "text_area", "showIf": "displayPrompt"}
/** @type {string} */
var promptText = script.promptText;

//@ui {"widget":"separator"}

//@input bool displayResultImage
/** @type {boolean} */
var displayResultImage = script.displayResultImage;

//@input Asset defaultImage {"showIf": "displayResultImage"}
/** @type {Asset} */
var defaultImage = script.defaultImage;

//@ui {"widget":"separator"}

//@input bool displayResultText = true
/** @type {boolean} */
var displayResultText = script.displayResultText;

//@input string defaultText {"widget" : "text_area", "showIf": "displayResultText"}
/** @type {string} */
var defaultText = script.defaultText;

//@ui {"widget":"separator"}

// @input SpinnerItem[] content
/** @type {SpinnerItem[]} */
var content = script.content;

//@ui {"widget":"separator"}

//@input bool setColorTextBg
/** @type {boolean} */
var setColorTextBg = script.setColorTextBg;

//@input bool hidePromptOnSpin
/** @type {boolean} */
var hidePromptOnSpin = script.hidePromptOnSpin;

//@ui {"widget":"separator"}

//@input bool advanced = true

//@ui {"widget":"group_start", "label":"Advanced Settings", "showIf": "advanced"}

//@input float delayBetweenImages = 0.1 {"widget":"slider", "min":0.0, "max":1.0, "step":0.01 }
/** @type {number} */
var delayBetweenImages = script.delayBetweenImages;

//@input float delayBeforeStop = 1.5 {"widget":"slider", "min":0.0, "max":3, "step":0.01 }
/** @type {number} */
var delayBeforeStop = script.delayBeforeStop;   

//@input Component.Text promptDisplay
/** @type {Text} */
var promptDisplay = script.promptDisplay;

//@input Component.Text resultTextDisplay
/** @type {Text} */
var resultTextDisplay = script.resultTextDisplay;

//@input Component.Image resultImageDisplay
/** @type {Image} */
var resultImageDisplay = script.resultImageDisplay;

//@ui {"widget":"group_end"}

// ======================================================

// USAGE: call this from another script
// , or use Behavior, to start randomizing!
script.randomizeStart = randomizeStart;

// Also allow for calling from old format of exposing api.
script.api.randomizeStart = randomizeStart;

// If Behavior is available, we can also listen to it.
if (global.behaviorSystem) {
    global.behaviorSystem.addCustomTriggerResponse("randomizeStart", randomizeStart);
}

// Call this API if you change the content of the spinner
// promptText or resultText from another script.
script.initVisuals = initVisuals;
script.api.initVisuals = initVisuals;
// ======================================================

var canRandomize = false;

var randomizeStartTime;
var setImageTime;

var n = script.content.length;
var curIndex = -1;

var updateEvent = script.createEvent("UpdateEvent");

function randomizeStart() {
    if (!canRandomize) {
        return;
    }

    if (displayPrompt && hidePromptOnSpin) {
        promptDisplay.enabled = false;
    }
    
    // start randomizing, disable user input
    randomizeStartTime = getTime();
    updateEvent.enabled = true;
    canRandomize = false;
}

function onUpdate() {
    var curTime = getTime();

    // If still choosing random image
    if ((curTime - randomizeStartTime) < delayBeforeStop) {
        if ((curTime - setImageTime) > delayBetweenImages) {
            
            var index = getRandomIntWithoutDoubles(curIndex);
            setDisplayToIndex(index);
            
            setImageTime = curTime;
            curIndex = index;
        }
    } else {        
        // Enable user input once we've chosen an image
        updateEvent.enabled = false;
        canRandomize = true;
    }
}

function randomInt(val) {
    return Math.floor(Math.random() * Math.floor(val));
}

function setDisplayToIndex(index) {
    if (content[index]) {
        if (displayResultImage) {
            if (content[index].image) {
                resultImageDisplay.enabled = true;
                resultImageDisplay.mainPass.baseTex = content[index].image;
            } else {
                Studio.log("[Warning] Missing image in content group #" + index);
                resultImageDisplay.enabled = false;
            }
        }

        if (displayResultText) {
            if (content[index].text) {
                resultTextDisplay.enabled = true;
                resultTextDisplay.text = content[index].text;
            } else {
                Studio.log("[Warning] Missing text in content group #" + index);
                resultTextDisplay.enabled = false;
            }
        }

        if (resultTextDisplay && setColorTextBg) {
            if (content[index].color) {
                resultTextDisplay.backgroundSettings.fill.color = content[index].color;
            } else {
                Studio.log("[Warning] Missing color in content group #" + index);
            }
        }
    }
}

function getRandomIntWithoutDoubles(lastIndex) {
    var index = randomInt(n);
    var i = 0;
    
    while (index == lastIndex && i < 10) {
        index = randomInt(n);
        i++;
    }
    
    return index;
}

function updateStoredVariables() {
    // Ensure that states are synced with script. properties
    content = script.content;
    n = content.length;
    
    promptText = script.promptText;
    defaultText = script.defaultText;
}

function initVisuals() {

    updateStoredVariables();
    
    if (displayPrompt) {
        if (promptText) {
            promptDisplay.text = promptText;
        }
    } else {
        if (promptDisplay) {
            promptDisplay.enabled = false;
        }
    }

    if (displayResultImage) {
        if (defaultImage) {
            resultImageDisplay.mainPass.baseTex = defaultImage;
        }
    } else {
        if (resultImageDisplay) {
            resultImageDisplay.enabled = false;
        }
    }

    if (displayResultText) {
        if (defaultText) {
            resultTextDisplay.text = defaultText;
        }
    } else {
        if (resultTextDisplay) {
            resultTextDisplay.enabled = false;
        }
    }
}

function validateInputs() {
    if (!(displayPrompt ? promptDisplay : true)) {
        Studio.log("[SpinnerController][Error] Please ensure `Prompt Display` is set in the `Advanced` section, or uncheck `Display Prompt`. This is where the Spinner `Prompt Text` will be shown.");
        return false;
    }

    if (!(displayResultText ? resultTextDisplay : true)) {
        Studio.log("[SpinnerController][Error] Please ensure `Result Display` is set in the `Advanced` section, or uncheck `Display Text`. This is where the Spinner result `Text` will be shown.");
        return false;
    }

    if (!(displayResultImage ? resultImageDisplay : true)) {
        Studio.log("[SpinnerController][Error] Please ensure `Result Image Display` is set in the `Advanced` section, or uncheck `Display Image`. This is where the Spinner `Image` result text will be shown.");
        return false;
    }

    return true;
}

function init() {
    if (!validateInputs()) {
        return false;
    }

    // Set Default States
    setImageTime = 0;
    randomizeStartTime = -1;
    updateEvent.enabled = false;

    initVisuals();
    updateEvent.bind(onUpdate);

    canRandomize = true;
}

init();
