// TextLookCustomizer.js
// Version: 0.1.0
// Event: Lens Initialized
// Description: Exposes some common text component settings. Useful when
// you want to control some text component on a different object.

//@input Component.Text textDisplay
/** @type {Text} */
var textDisplay = script.textDisplay;

//@ui {"widget":"separator"}

//@input bool modifyLook
/** @type {boolean} */
var modifyLook = script.modifyLook;

//@ui {"widget":"group_start", "label":"Settings", "showIf": "modifyLook"}

//@input vec4 textColor {"widget":"color"}
/** @type {vec4} */
var textColor = script.textColor;

//@input int textSize {"widget":"slider", "min":50, "max":300, "step":1 }
/** @type {number} */
var textSize = script.textSize;

//@input vec4 textOffset
/** @type {vec4} */
var textOffset = script.textOffset;

//@input Asset.Font textFont
/** @type {Font} */
var textFont = script.textFont;

//@input bool textBackground
/** @type {boolean} */
var textBackground = script.textBackground;
//@ui {"widget":"group_start", "label":"Settings", "showIf": "textBackground"}
//@input float textBgRadius {"widget":"slider", "min":0.0, "max":30.0, "step":0.1 }
/** @type {number} */
var textBgRadius = script.textBgRadius;

//@input vec4 textBgColor {"widget":"color"}
/** @type {vec4} */
var textBgColor = script.textBgColor;

//@input vec4 textBgMargin
/** @type {vec4} */
var textBgMargin = script.textBgMargin;
//@ui {"widget":"group_end"}

//@input bool textOutline
/** @type {boolean} */
var textOutline = script.textOutline;
//@ui {"widget":"group_start", "label":"Settings", "showIf": "textOutline"}
//@input vec4 outlineColor {"widget":"color"}
/** @type {vec4} */
var outlineColor = script.outlineColor;

//@input float outlineSize {"widget":"slider", "min":0.0, "max":1.0, "step":0.01 }
/** @type {number} */
var outlineSize = script.outlineSize;
//@ui {"widget":"group_end"}

//@input bool textDropshadow
/** @type {boolean} */
var textDropshadow = script.textDropshadow;
//@ui {"widget":"group_start", "label":"Settings", "showIf": "textDropshadow"}
//@input vec4 dropshadowColor {"widget":"color"}
/** @type {vec4} */
var dropshadowColor = script.dropshadowColor;

//@input vec2 dropshadowOffset
/** @type {vec2} */
var dropshadowOffset = script.dropshadowOffset;
//@ui {"widget":"group_end"}
    
//@ui {"widget":"group_end"}


/**
 * @param {Text} textComponent 
 */
function modifyTextVisual(textComponent) {

    textComponent.size = textSize;

    if (textFont) {
        textComponent.font = textFont;
    }

    const tcSt = textComponent.getSceneObject().getComponent("ScreenTransform");
    if (tcSt) {
        const offset = Rect.create(textOffset.x, textOffset.y, textOffset.z, textOffset.w);
        tcSt.offsets = offset;
    }

    textComponent.textFill.color = textColor;

    textComponent.backgroundSettings.enabled = textBackground;
    var margin = Rect.create(textBgMargin.x, textBgMargin.y, textBgMargin.z, textBgMargin.w);
    textComponent.backgroundSettings.margins = margin;
    textComponent.backgroundSettings.fill.color = textBgColor;
    textComponent.backgroundSettings.cornerRadius = textBgRadius;

    textComponent.dropshadowSettings.enabled = textDropshadow;
    textComponent.dropshadowSettings.fill.color = dropshadowColor;
    textComponent.dropshadowSettings.offset = dropshadowOffset;

    textComponent.outlineSettings.enabled = textOutline;
    textComponent.outlineSettings.fill.color = outlineColor;
    textComponent.outlineSettings.size = outlineSize;

}

function validateInputs() {
    if (!(modifyLook ? textDisplay : true)) {
        Studio.log("[TextLookCustomizer][Error] Please ensure `Text Display` is set, or uncheck `Modify Look`. This is the text that will be modified.");
        return false;
    }
    return true;
}

function init() {
    if (!validateInputs()) {
        return false;
    }

    if (modifyLook) {
        modifyTextVisual(textDisplay);
    }
}

init();